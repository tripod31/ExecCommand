perl test.pl
pause
