ruby test.rb
pause
